Music-Player(SpotifyClone) MERN Stack website

Week 2 task submission of internship presented by Edunet Foundation in collaboration with EY GDS and AICTE


Technology Used
Frontend
ReactJS
TailwindCSS
Backend
NodeJS
ExpressJS
Database
MongoDB
